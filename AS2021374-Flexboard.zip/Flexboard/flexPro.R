library(readxl)
library(dplyr)
library(ggplot2)
library(GGally)
library(raster)
library(magrittr)
library(ggstatsplot)
library(tidyr)
library(plotly)
library(forcats)
library(tsibble)
library(leaflet)
library(htmltools)
library(scales)
library(ceylon)
library(tidyverse)
library(sp)
library(rnaturalearth)
library(knitr)
library(RColorBrewer)

display.brewer.all()
gender_palette <- scale_fill_brewer(palette = "Set2")

pal1 <-brewer.pal(8, "Dark2")[c(3,4)]
residence_palette <- scale_fill_manual(values=pal1,
                                       name = "Residency Type")


d1 <- read_xlsx("C:\\Users\\LENOVO\\Desktop\\New folder\\Table01Populationbysingleyearsofagesexandsector_2012.xlsx",
        sheet="Table 01"       
               )
d2 <-read_xlsx("C:\\Users\\LENOVO\\Desktop\\New folder\\Table01Populationbysingleyearsofagesexandsector_2012.xlsx",
               sheet="Rural"       
)
d3 <-read_xlsx("C:\\Users\\LENOVO\\Desktop\\New folder\\Table01Populationbysingleyearsofagesexandsector_2012.xlsx",
               sheet="Urban"       
)
d4 <- read_xlsx("C:\\Users\\LENOVO\\Desktop\\New folder\\Table04Departuresofthechildrenbyagegroup_sexandyear.xlsx",
)


d5 <- read_xlsx("C:\\Users\\LENOVO\\Desktop\\New folder\\Table05Arrivalsofthechildrenby_sexandyear.xlsx"
)

d6 <- read_xlsx("C:\\Users\\LENOVO\\Desktop\\New folder\\Table01Studentsofgovernmentschoolenrollment_byprovincedistrictandgrade2020.xlsx",
                sheet="province")


d7 <- read_xlsx("C:\\Users\\LENOVO\\Desktop\\New folder\\Table01Studentsofgovernmentschoolenrollment_byprovincedistrictandgrade2020.xlsx",
                sheet="Table 01")

getwd()
setwd("C:/Users/LENOVO/Desktop/Flexboard")



# Population datasets
d1 <- read_xlsx("data/Table01Populationbysingleyearsofagesexandsector_2012.xlsx", sheet = "Table 01")
d2 <- read_xlsx("data/Table01Populationbysingleyearsofagesexandsector_2012.xlsx", sheet = "Rural")
d3 <- read_xlsx("data/Table01Populationbysingleyearsofagesexandsector_2012.xlsx", sheet = "Urban")

# Population departure & arrival
d4 <- read_xlsx("data/Table04Departuresofthechildrenbyagegroup_sexandyear.xlsx")
d5 <- read_xlsx("data/Table05Arrivalsofthechildrenby_sexandyear.xlsx")

# School enrollment
d6 <- read_xlsx("data/Table01Studentsofgovernmentschoolenrollment_byprovincedistrictandgrade2020.xlsx", sheet = "province")
d7 <- read_xlsx("data/Table01Studentsofgovernmentschoolenrollment_byprovincedistrictandgrade2020.xlsx", sheet = "Table 01")




Type=c(rep("Urban"),times=18)
d3 <- d3|> mutate(Type="Urban")

d2 <- d2|> mutate(Type="Rural")
d2d3 <- bind_rows(d2,d3)

childPop <- d2d3

v1 <- sum(childPop$Male)
v2 <- sum(childPop$Female)

childPop$Age <-factor(childPop$Age, levels = c("Under 01", as.character(1:17)))

p1 <-ggplot(childPop,aes(x=Age,y=Male,fill=Type))+
  geom_col(position="dodge")
ggplot(childPop,aes(x=Age,y=Female,fill=Type))+
  geom_col(position="dodge")



p11 <- ggplot(childPop,aes(x=Age,y=`Both sexes`,fill=Type))+
  geom_col(position="dodge")+
  labs(y="Total Count",
       x="Age(Years)")+
  scale_y_continuous(
    breaks = seq(0,300000,by=50000),
    limits = c(0,300000)
  )+
  residence_palette+
  theme(
    axis.text.x = element_text(
      angle = 30,
      hjust=0.8
    ),
    panel.grid = element_blank()
    
  )

childPop|>filter(Type=="Rural")|>
  ggplot(aes(x=fct_reorder(Age,`Both sexes`),y=`Both sexes`,fill=Type))+
  geom_col()

childPop|>filter(Type=="Urban")|>
  ggplot(aes(x=fct_reorder(Age,`Both sexes`),y=`Both sexes`,fill=Type))+
  geom_col()
v3 <- sum(childPop$`Both sexes`[childPop$Type=="Rural"])
v4 <- sum(childPop$`Both sexes`[childPop$Type=="Urban"])

pchildPop <-childPop |> pivot_longer(
  cols = c("Male", "Female"),
  names_to = "Gender",
  values_to = "Counts"
)

p12 <-ggplot(pchildPop,aes(x=Age,y=`Counts`,fill=Gender))+
  geom_col()+
  facet_grid(~Gender)+
  gender_palette+
  theme(
    axis.text.x = element_text(
      angle = 45,
      hjust=0.8
    ),
    panel.grid = element_blank(),
    legend.position = "none" 
    
  )
p13 <-ggplot(pchildPop,aes(x=Age,y=`Counts`,fill=Gender))+
  geom_col(position = "dodge")+
  gender_palette +
  theme(
    axis.text.x = element_text(
      angle = 45,
      hjust=0.8
    ),
    panel.grid = element_blank(),
    legend.position = "none" 
    
  )


pchildPop|>filter(Type=="Rural")|>
  ggplot(aes(x=fct_reorder(Age,`Counts`),y=`Counts`,fill=Gender))+
  geom_col(position = "dodge")

pchildPop|>filter(Type=="Rural")|>
  ggplot(aes(x=fct_reorder(Age,`Counts`),y=`Counts`,fill=Gender))+
  geom_col()+
  facet_grid(~Gender)

 pchildPop|>filter(Type=="Urban")|>
  ggplot(aes(x=fct_reorder(Age,`Counts`),y=`Counts`,fill=Gender))+
  geom_col(position = "dodge")

pchildPop|>filter(Type=="Urban")|>
  ggplot(aes(x=fct_reorder(Age,`Counts`),y=`Counts`,fill=Gender))+
  geom_col()+
  facet_grid(~Gender)

p14 <-ggplot(pchildPop, aes(x = Age, y = Counts, fill = Gender)) +
  geom_col(position = "dodge") +
  facet_wrap(~Type) +
  gender_palette +
  labs(
    title = "Counts by Age, Gender, and Type",
    x = "Age",
    y = "Counts"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

p16 <- ggplot(pchildPop, aes(x = Age, y = Counts, fill = Gender)) +
  geom_col() +
  facet_grid(Type ~ Gender) +
  gender_palette +
  labs(title = "Counts by Age, Gender, and Type") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

p15 <- ggplot(pchildPop, aes(x = Age, y = Type, fill = Counts)) +
  geom_tile(color = "white") +
  scale_fill_viridis_c() +
  facet_wrap(~Gender) +
  labs(title = "Heatmap of Counts by Age, Type, and Gender") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

ggplot(pchildPop, aes(x = Age, y = Type, fill = Counts)) +
  geom_raster() +
  scale_fill_viridis_c() +
  facet_wrap(~Gender) +
  labs(title = "Heatmap of Counts by Age, Type, and Gender") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

pcp<- pchildPop %>%group_by(Gender) %>%
  summarise(count=sum(Counts), .groups = "drop")
p16 <- ggplot(pcp, aes(x = Gender, y = count, fill = Gender)) +
  geom_col() +
  labs(title = "Counts by Gender",
       x = "Gender",
       y = "Counts") +
  gender_palette+
  geom_text(
    aes(
      label = count,
      vjust=-0.5
    )
  )+
  theme(
    legend.position = "none",
    panel.grid = element_blank()
  )


p17 <- ggplot(pchildPop, aes(x=Type, y=Counts,fill=Type))+
  geom_col()+
  residence_palette+
  geom_text(
    stat="summary",
    fun=sum,
    aes(
      label = after_stat(y)),
    vjust=-0.5
  )+
  theme(
    panel.grid = element_blank(),
    legend.position = "none"
  )

# Departures


colnames(d4)




tidy_d4 <- d4 %>%
  pivot_longer(
    cols = -Year,
    names_to = c("Gender", "Age_Group"),
    names_sep = " ",
    values_to = "Population"
  ) %>%
  mutate(
    Age_Group = factor(Age_Group, levels = c("0-4", "5-9", "10-14", "15-17")),
    Gender = factor(Gender, levels = c("Male", "Female"))
  ) %>%
  arrange(Year, Age_Group, Gender)

tidy_d4_ts <-as_tsibble(tidy_d4,key=c(Age_Group, Gender),index="Year")


ggplot(tidy_d4_ts, aes(x=Year, y=Population, colour=Age_Group))+
  geom_line(size=0.9)+
  facet_grid(~Gender)+
  theme(panel.grid.minor = element_blank()
        )


# Create smoothed interactive plot
tidy_d4_ts$Year
pt<- tidy_d4_ts %>%
  ggplot(aes(x = Year, y = Population, color = Age_Group, 
             group = Age_Group, text = paste(
               "Year:", Year,
               "<br>Age Group:", Age_Group,
               "<br>Population:", scales::comma(Population)
             ))) +
  geom_line(size = 0.9) +
  geom_point()+
  facet_grid(~Gender) +
  scale_y_continuous(labels = scales::comma) +
  scale_x_continuous(
    breaks = seq(2015,2022,by=1)
  )+
  scale_color_brewer(palette = "Set1") + 
  labs(
    title = "Population Trends by Age Group and Gender",
    x = "Year",
    y = "Population Count",
    color = "Age Group"
  ) +
  theme_minimal() +
  theme(
    plot.background = element_rect(fill = "#f5f5f5", color = NA),
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(linewidth = 0.1),
    legend.position = "bottom",
    strip.text = element_text(face = "bold")
  )

# Convert to interactive plot
p21<- ggplotly(pt, tooltip = "text") %>%
  layout(
    hoverlabel = list(bgcolor = "white"),
    legend = list(orientation = "h", y = -0.2),
    margin = list(b = 100)  
  ) %>%
  config(displayModeBar = TRUE)



ggplot(tidy_d4_ts, aes(x=Year, y=Population, colour=Age_Group))+
  geom_line()+
  facet_wrap(~Gender)+
  scale_x_continuous(
    breaks = seq(2015,2022,by=1)
  )+
  gender_palette + 
  labs(
    title = "Population Trends by Age Group and Gender",
    x = "Year",
    y = "Population Count",
    color = "Age Group"
  ) +
  theme_minimal() +
  theme(
    plot.background = element_rect(fill = "#f5f5f5", color = NA),
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(linewidth = 0.1),
    legend.position = "bottom",
    strip.text = element_text(face = "bold")
  )

ggplot(tidy_d4_ts, aes(x=Year, y=Population, colour=Gender))+
  geom_line()+
  facet_grid(~Age_Group)+
  scale_x_continuous(
    breaks = seq(2015,2022,by=1)
  )+
  scale_colour_brewer(palette = "Set2")+
  labs(
    title = "Population Trends by Age Group and Gender",
    x = "Year",
    y = "Population",
    color = "Gender"
  ) +
  theme_minimal() +
  theme(
    plot.background = element_rect(fill = "#f5f5f5", color = NA),
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(linewidth = 0.1),
    legend.position = "bottom",
    strip.text = element_text(face = "bold")
  )

tidy_d4_ts%>% filter(Gender=="Male")%>%
  ggplot(aes(x=Year, y=Population,colour = Age_Group))+
  geom_line()


tidy_d4_sum <- tidy_d4_ts %>%
  as_tibble() %>%  # Convert to regular tibble for aggregation
  group_by(Year, Age_Group) %>%
  summarize(Total_Population = sum(Population), .groups = "drop")


pt2<-ggplot(tidy_d4_sum, aes(x = Year, y = Total_Population, 
                        color = Age_Group, group = Age_Group,
                        text = paste0(
                          "<b>", Age_Group, "</b><br>",
                          "Year: ", Year, "<br>",
                          "Total Population: ", scales::comma(Total_Population)
                          ))) +
  geom_line(size = 1.2) +
  geom_point(size = 2.5) +  
  scale_y_continuous(labels = scales::comma) +
  scale_x_continuous(breaks = seq(2015, 2022, by = 1)) +
  scale_color_brewer(palette = "Set2") +
  labs(
    title = "Total Population by Age Group (2015-2022)",
    subtitle = "Sum of Male and Female Populations",
    x = "Year",
    y = "Total Population",
    color = "Age Group"
  ) +
  theme_minimal() +
  theme(
    legend.position = "bottom",
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold", size = 14),
    axis.title = element_text(face = "bold")
    
  )

p22 <- ggplotly(pt2, tooltip = "text") %>%
  layout(
    hoverlabel = list(
      bgcolor = "white",
      font = list(size = 12)
    ),
    legend = list(
      orientation = "h",
      y = -0.2  
    )
  ) %>%
  config(displayModeBar = TRUE) 

line_plot <- ggplot(tidy_d4_sum,
                    aes(x = Year, y = Total_Population,
                        color = Age_Group,
                        group = Age_Group,
                        text = paste(
                          "<b>", Age_Group, "</b><br>",
                          "Year: ", Year, "<br>",
                          "Population: ", comma(Total_Population)
                        ))) +
                      geom_line(size = 1.2, alpha = 0.8) +
                      geom_point(size = 2.5) +
                      scale_color_viridis_d(option = "D", end = 0.9) +  
                      scale_y_continuous(labels = comma, expand = c(0.1, 0)) +
                      scale_x_continuous(breaks = seq(2015, 2022, 1)) +
                      labs(
                        title = "Population Trends by Age Group (2015-2022)",
                        x = "Year",
                        y = "Total Population (sum of both genders)",
                        color = "Age Group"
                      ) +
                      theme_minimal() +
                      theme(
                        legend.position = "bottom",
                        plot.title = element_text(face = "bold", size = 14),
                        panel.grid.minor = element_blank()
                      )
                    
ggplotly(line_plot, tooltip = "text") %>%
                      layout(
                        hoverlabel = list(
                          bgcolor = "white",
                          font = list(size = 12)
                        ),
                        legend = list(
                          orientation = "h",
                          y = -0.3  
                        ),
                        margin = list(b = 80)  
                      ) %>%
                      config(displayModeBar = TRUE)



age_group_data <- tidy_d4_ts %>%
  as_tibble() %>%
  group_by(Year, Age_Group) %>%
  summarize(Total_Population = sum(Population), .groups = "drop")


pt4 <- ggplot(age_group_data, 
               aes(x = Year, y = Age_Group,
                   fill = Total_Population,
                   text = paste0(
                     "Age Group: ", Age_Group, "<br>",
                     "Year: ", Year, "<br>",
                     "Total Population: ", comma(Total_Population)
                   ))) +
  geom_tile(color = "white", linewidth = 0.5) +  # Rectangle for each cell
  scale_fill_viridis_c(option = "plasma", labels = comma) +  # Color scale
  scale_x_continuous(breaks = seq(2015, 2022, 1)) +  # Year ticks
  labs(title = "Population Distribution by Age Group and Year",
       x = "Year",
       y = "Age Group",
       fill = "Population") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


p23 <-ggplotly(pt4, tooltip = "text") %>%
  layout(
    hoverlabel = list(bgcolor = "white"),
    margin = list(l = 100, r = 50)  # Adjust margins
  ) %>%
  config(displayModeBar = TRUE)


yearly_population <- tidy_d4_ts %>%
  as_tibble() %>%
  group_by(Year) %>%
  summarize(Total_Population = sum(Population), .groups = "drop")


p25 <- ggplot(yearly_population,
                   aes(x = Year, y = Total_Population)) +
  geom_line(color = "#4E79A7", size = 1.5, alpha = 0.8) +  # Single line
  geom_point(color = "#E15759", size = 3) +                # Highlight points
  scale_y_continuous(labels = comma, 
                     expand = expansion(mult = c(0.05, 0.15))) +
  scale_x_continuous(breaks = seq(2015, 2022, 1)) +
  labs(title = "Total Population Trend (2015-2022)",
       x = "Year",
       y = "Total Population") +
  theme_minimal() +
  theme(
    plot.title = element_text(face = "bold", size = 14, hjust = 0.5),
    panel.grid.minor = element_blank(),
    axis.title = element_text(face = "bold")
  )


p24 <- ggplotly(p25, tooltip = "text") %>%
  layout(
    hoverlabel = list(
      bgcolor = "white",
      bordercolor = "lightgray",
      font = list(size = 12)
    ),
    margin = list(t = 60)  # Add top margin for title
  ) %>%
  config(displayModeBar = TRUE)


#Arrivals

d5_tidy <- d5 %>% pivot_longer(
  cols = c("Male","Female","Total"),
  values_to = "Population",
  names_to = "Gender"
) %>%
  mutate(Gender=factor(Gender,  levels=c("Male","Female","Total")))%>%
  as_tsibble(index=Year, key = Gender)

d5_tidy%>%filter(Gender=="Total")%>%
  ggplot( aes(x=Year,y=Population))+
  geom_line(colour="red")

d5_tidy %>% filter(Gender %in% c("Male","Female"))%>%
  ggplot(aes(x=Year, y=Population, colour=Gender))+
  geom_line()


p31 <- d5_tidy %>%
  filter(Gender == "Total") %>%
  ggplot(aes(x = Year, y = Population
             )) +
  geom_line(color = "red", size = 1.2) +
  geom_point(color = "darkred", size = 2.1) +
  scale_y_continuous(labels = scales::comma) +
  scale_x_continuous(
    breaks = seq(2015,2021,by=1)
  )
  labs(title = "Total Population Trend", x = "Year", y = "Population") +
  theme_minimal()


p32 <- d5_tidy %>%
  filter(Gender != "Total") %>%  
  ggplot(aes(x = Year, y = Population, color = Gender,
             group = Gender,
             text = paste("Gender:", Gender, "<br>Year:", Year, 
                          "<br>Population:", scales::comma(Population)))) +
  geom_line(size = 1.2) +
  geom_point(size = 2) +
  scale_color_manual(values = c("Male" = "blue", "Female" = "purple")) +
  scale_y_continuous(labels = scales::comma) +
  labs(title = "Population by Gender", x = "Year", y = "Population") +
  theme_minimal()


p33 <-ggplotly(p32, tooltip = "text") %>%
  layout(
    hoverlabel = list(bgcolor = "white"),
    legend = list(orientation = "h", y = -0.2)) %>%
  config(displayModeBar = TRUE)

# by district schools

d6_tidy <- d6%>% 
  pivot_longer(
    cols=-Province,
    names_to = "Grade",
    values_to = "Population"
  )

p41<-d6_tidy%>% filter(Grade=="Total",
                  Province!="Sri Lanka")%>%
ggplot(aes(x=reorder(Province,Population), y=Population))+
  geom_col( fill="steelblue")+
  labs(
    
    x=""
  )+
  scale_x_discrete(
    labels = function(x) gsub(" ", "\n", x)  # Replace spaces with newlines
  ) +
  coord_flip()+
  theme(
    panel.grid = element_blank(),
  )
  

d6_tidy%>% filter(Grade!="Total",
                  Province!="Sri Lanka")%>%
ggplot(aes(x=Grade, y=Population, fill=Province))+
  geom_col()+
  facet_grid(~Province)

d6_tidy%>% filter(Grade!="Total",
                  Province!="Sri Lanka")%>%
  ggplot(aes(x=Province, y=Population, fill=Province))+
  geom_col()+
  facet_grid(~Grade)

d6_tidy%>% filter(Grade!="Total",
                  Province!="Sri Lanka")%>%
  ggplot(aes(x=Grade, y=Population, fill=Province))+
  geom_col(position="dodge")

p42 <- d6_tidy%>% filter(Grade!="Total",
                  Province!="Sri Lanka")%>%
  ggplot(aes(x=reorder(Grade,Population), y=Province, fill=Population))+
  geom_raster()+
  scale_fill_viridis_c()+
  scale_x_discrete(labels = function(x) gsub("Grade ", "Grade\n", x) )+
  scale_y_discrete(labels = function(x) gsub(" ", "\n", x) )+
  labs(
    title="Population of Students by Grades",
    x="Grade",
    y=""
  )
  theme(
    axis.title.x = element_text(
      angle = 90
    )
  )

d6_tidy%>% filter(Grade!="Total",
                  Province!="Sri Lanka")%>%
  ggplot(aes(x=Grade, y=reorder(Province,Population) ,fill=Population))+
  geom_raster()+
  scale_fill_viridis_c()

d6_tidy%>% filter(Grade!="Total",
                  Province!="Sri Lanka")%>%
  ggplot(aes(x = Grade, y = Population, color = Province, group = Province)) +
  geom_line(linewidth = 1) +
  geom_point(size = 2)
 
d6_tidy %>%
    filter(Grade != "Total", Province != "Sri Lanka") %>%
    ggplot(aes(x = Grade, y = Population, group = 1)) +
    geom_line(color = "steelblue") +
    geom_point(color = "steelblue") +
    facet_wrap(~Province, scales = "free_y")
d6Map <- d6%>% filter(Province !="Sri Lanka")


d6_tidy_map <-d6_tidy %>%filter(Grade!="Total",
                                Province!="Sri Lanka")%>%
  mutate(Province = case_when(
    Province == "Western province" ~ "WESTERN",
    Province == "Central province" ~ "CENTRAL",
    Province == "Southern province" ~ "SOUTHERN",
    Province == "Northern province" ~ "NORTHERN",
    Province == "Eastern province" ~ "EASTERN",
    Province == "North western province" ~ "NORTH WESTERN",
    Province == "North central province" ~ "NORTH CENTRAL",
    Province == "Uva province" ~ "UVA",
    Province == "Sabaragamuwa province" ~ "SABARAGAMUWA",
    TRUE ~ Province 
  ))

province_map <- province %>%
  left_join(d6_tidy_map, by = c("PROVINCE" = "Province"))
colnames(province_map)

grade_levels <- sort(unique(province_map$Grade))


plot_map <- province_map %>%
  filter(!is.na(Grade), Grade != "Total")

map_plots <- list()
bar_plots <- list()

for(g in grade_levels){
  df <- plot_map %>% filter(Grade == g)

  map_plots[[g]] <- ggplot(df) +
    geom_sf(aes(fill = Population), color = "black", size = 0.2) +
    scale_fill_viridis_c(option = "C", labels = comma) +
    labs(title = paste("Sri Lanka Provinces —", g)) +
    theme_minimal() +
    theme(panel.grid.major = element_blank())

  bar_plots[[g]] <- ggplot(df, aes(x = reorder(PROVINCE, Population), y = Population, fill = Population)) +
    geom_col() +
    scale_fill_viridis_c(option = "C", labels = comma) +
    coord_flip() +
    labs(title = paste("Population by Province —", g), x = "Province", y = "Population") +
    theme_minimal()
}


ggplot(d7, aes(x=District, y=Total))+
  geom_col()

d7_tidy <-d7[,-17] %>% 
  pivot_longer(
    cols=-District,
    names_to = "Grades",
    values_to = "Population"
  )

unique(d7_tidy$District)
unique(district$DISTRICT)

d7_tidy_map <- d7_tidy %>%
  mutate(District = case_when(
    District == "Colombo" ~ "COLOMBO",
    District == "Gampaha" ~ "GAMPAHA",
    District == "Kalutara" ~ "KALUTARA",
    District == "Kandy" ~ "KANDY",
    District == "Matale" ~ "MATALE",
    District == "Nuwara Eliya" ~ "NUWARA ELIYA",
    District == "Galle" ~ "GALLE",
    District == "Matara" ~ "MATARA",
    District == "Hambantota" ~ "HAMBANTOTA",
    District == "Jaffna" ~ "JAFFNA",
    District == "Kilinochchi" ~ "KILINOCHCHI",
    District == "Mannar" ~ "MANNAR",
    District == "Vavuniya" ~ "VAVUNIYA",
    District == "Mullaitivu" ~ "MULLAITIVU",
    District == "Batticaloa" ~ "BATTICALOA",
    District == "Ampara" ~ "AMPARA",
    District == "Trincomalee" ~ "TRINCOMALEE",
    District == "Kurunegala" ~ "KURUNEGALA",
    District == "Puttalam" ~ "PUTTALAM",
    District == "Anuradhapura" ~ "ANURADHAPURA",
    District == "Polonnaruwa" ~ "POLONNARUWA",
    District == "Badulla" ~ "BADULLA",
    District == "Monaragala" ~ "MONARAGALA",
    District == "Ratnapura" ~ "RATNAPURA",
    District == "Kegalle" ~ "KEGALLE",
    TRUE ~ District
  ))
district_map <- district %>%
  left_join(d7_tidy_map, by = c("DISTRICT" = "District"))



p52 <- d7_tidy%>% 
  ggplot(aes(x=reorder(Grades,Population), y=District, fill=Population))+
  geom_raster()+
  scale_fill_viridis_c()+
  scale_x_discrete(labels = function(x) gsub("Grade ", "Grade\n", x) )+
  scale_y_discrete(labels = function(x){
    x<- gsub(" ", "\n", x) 
    x <- gsub("Special education", "Special\neducation", x)
                   })+
  labs(
    title="Population of Students by Grades",
    y=" ",
    x="Grade"
  )
theme(
  axis.title.x = element_text(
    angle = 90
  )
)

ggplot(d7_tidy, aes(x=District, y=Population,fill=District))+
  geom_col()+
  facet_grid(~Grades)

ggplot(d7_tidy, aes(x=District, y=Population,fill=District))+
  geom_col()+
  facet_wrap(~Grades,
             nrow = 5)


ggplot(d7_tidy, aes(x=Grades, y=Population,fill=Grades))+
  geom_col()+
  facet_grid(~District)

ggplot(d7_tidy, aes(x=Grades, y=Population,fill=Grades))+
  geom_col()+
  facet_wrap(~District)

d7_tidy %>% 
  ggplot(aes(x = as.numeric(gsub("Grade", "", Grades)), y = Population, group = District)) +
  geom_line(color = "steelblue") +
  facet_wrap(~District, scales = "free_y", ncol = 3) +
  scale_x_continuous(breaks = c(1,5,10,15,20), labels = paste0("G",c(1,5,10,15,20)))

d7_tidy %>%
  ggplot(aes(x = as.numeric(gsub("Grade", "", Grades)), y = Population, fill = District)) +
  geom_area(position = "fill") +
  scale_x_continuous(breaks = seq(1,20,2), labels = paste0("G",seq(1,20,2))) +
  scale_y_continuous(labels = scales::percent) 

 ggplot(d7_tidy, aes(x = Grades, y = Population, fill = Grades)) +
  geom_col() +
  facet_wrap(~District, scales = "free_y") + 
  scale_y_continuous(labels = scales::comma)



crs(sf_sl_0)
ggplot(sf_sl_0) +
 geom_sf()
data(sf_sl_0)
class(sf_sl_0)

province$PROVINCE
district$DISTRICT
ggplot(data=province) +
  geom_sf()
ggplot(data=district) +
  geom_sf()

ggplot() +
  geom_sf(data=province, lwd=2, col="black") + 
  geom_sf(data=district, linetype=21, col="red")


p5<-p52/p42
p6 <-p13/p14

d7_sum <- d7_tidy %>%
  group_by(District) %>%
  summarise(Population = sum(Population, na.rm = TRUE), .groups = "drop")

p8 <-ggplot(d7_sum, aes(x = reorder(District, -Population), y = Population)) +
  geom_col(fill = "steelblue") +
  coord_flip()+
  labs(title = "Population by District",
       x = "",
       y = "Total Population") +
  theme(
    panel.grid = element_blank()
  ) +
  theme(legend.position = "none") +
  scale_y_continuous(labels = scales::comma)

p9 <- ggplotly(
  p8,
  tooltip = c("y")  
) %>% 
  layout(
    hoverlabel = list(
      bgcolor = "white",  
      font = list(size = 14)  
    ),
    margin = list(l = 100)  
  ) %>%
  config(displayModeBar = TRUE)

p10 <- ggplotly(
  p41,
  tooltip = c("y"),  
  originalData = TRUE     
) %>%
  layout(
    hoverlabel = list(
      bgcolor = "white",
      font = list(size = 12)
    ),
    margin = list(l = 120),  
    yaxis = list(title = "")
  ) %>%
  config(displayModeBar = TRUE)



